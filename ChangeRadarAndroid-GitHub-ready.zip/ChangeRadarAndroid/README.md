# ChangeRadar for Android

This is the Android Studio project for a native Android shell around the current ChangeRadar service. It includes an Android launcher entry, native header and bottom navigation, share action, offline state with retry, browser handling for external links, and Android back navigation. The ChangeRadar workspace and authentication currently load from the live hosted service, so the app requires internet access for those features.

## Build an APK

### Android Studio
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder as a project.
3. Allow Gradle sync to complete.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions
1. Create a private or public GitHub repository and upload the project files.
2. Upload the **contents** of this folder to the root of a GitHub repository (so `app/`, `build.gradle.kts`, and `.github/` are at the repository root).
3. Push the files to the `main` branch.
4. Open **Actions → Build ChangeRadar Android APK**. If it did not start automatically, open the workflow and choose **Run workflow**.
5. Open the successful run and download the `ChangeRadar-debug-apk` artifact. Unzip the downloaded artifact to get `app-debug.apk`.

## Important
- The current environment did not have the Android SDK or Gradle installed, so an APK could not be compiled here. This download is the complete project source, not an APK.
- The generated debug APK is for testing/sideloading. A Play Store release should use a securely managed signing key and a release build.
- The app loads `https://changeradar-ut6w8y.v2.appdeploy.ai/`; demo updates and any limitations of the hosted service remain the same as the website.
