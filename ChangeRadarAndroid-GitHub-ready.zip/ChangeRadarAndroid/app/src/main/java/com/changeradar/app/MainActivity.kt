package com.changeradar.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var offlinePanel: LinearLayout
    private lateinit var shell: LinearLayout
    private val appUrl = "https://changeradar-ut6w8y.v2.appdeploy.ai/#/welcome"
    private val green = Color.rgb(20, 129, 87)
    private val ink = Color.rgb(26, 43, 36)
    private val pale = Color.rgb(244, 251, 247)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = pale
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(12), dp(10)); setBackgroundColor(pale)
        }
        val brand = TextView(this).apply {
            text = "◉  ChangeRadar"; textSize = 20f; setTextColor(green); setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(46), 1f))
        val share = makeButton("Share") { shareApp() }
        header.addView(share)
        shell.addView(header)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true; indeterminateTintList = android.content.res.ColorStateList.valueOf(green)
        }
        shell.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        webView = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mediaPlaybackRequiresUserGesture = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) { progress.visibility = View.VISIBLE; offlinePanel.visibility = View.GONE }
                override fun onPageFinished(view: WebView?, url: String?) { progress.visibility = View.GONE }
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    return if (uri.host == "changeradar-ut6w8y.v2.appdeploy.ai") false else {
                        startActivity(Intent(Intent.ACTION_VIEW, uri)); true
                    }
                }
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame && !isOnline()) offlinePanel.visibility = View.VISIBLE
                }
            }
        }
        shell.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        offlinePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(24), dp(24), dp(24)); setBackgroundColor(pale); visibility = View.GONE
            addView(TextView(this@MainActivity).apply { text = "You’re offline"; textSize = 24f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER })
            addView(TextView(this@MainActivity).apply { text = "Reconnect to the internet, then try again."; textSize = 15f; setTextColor(ink); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(18)) })
            addView(makeButton("Try again") { loadApp() })
        }
        shell.addView(offlinePanel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(5), dp(6), dp(5), dp(6)); setBackgroundColor(Color.WHITE)
        }
        listOf("Home" to "#/app", "Updates" to "#/updates", "Guide" to "#/how", "Feedback" to "#/feedback").forEach { (label, route) ->
            val b = makeButton(label) { navigate(route) }
            bottom.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(2); marginEnd = dp(2) })
        }
        shell.addView(bottom)
        setContentView(shell)
        if (savedInstanceState != null) webView.restoreState(savedInstanceState) else loadApp()
    }

    private fun loadApp() {
        if (isOnline()) { offlinePanel.visibility = View.GONE; webView.visibility = View.VISIBLE; webView.loadUrl(appUrl) }
        else { webView.visibility = View.GONE; offlinePanel.visibility = View.VISIBLE; progress.visibility = View.GONE }
    }

    private fun navigate(route: String) {
        if (webView.url.isNullOrBlank()) loadApp() else webView.evaluateJavascript("window.location.hash = '${route.removePrefix("#")}'", null)
    }

    private fun shareApp() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "ChangeRadar"); putExtra(Intent.EXTRA_TEXT, "Try ChangeRadar: $appUrl")
        }
        startActivity(Intent.createChooser(intent, "Share ChangeRadar"))
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false; setTextColor(green)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(232, 246, 238))
        setPadding(dp(8), 0, dp(8), 0); setOnClickListener { action() }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); webView.saveState(outState) }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
